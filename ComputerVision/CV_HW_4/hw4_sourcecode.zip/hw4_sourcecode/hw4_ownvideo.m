I = imread('image21.jpg');
I2=double(I(:,:,1));
I3 = imread('image29.jpg');
I4=double(I3(:,:,1));
SI2 = double(gaussian_filter(I2,1));
SI4 = double(gaussian_filter(I4,1));
t = SI4-SI2;
[Ix,Iy] = gradient(SI2); % first order partials
A = [Ix(:),Iy(:)];
fx=  uint8(t)./uint8(Ix);
fy = uint8(t)./uint8(Iy);

figure(1);
quiver(uint8(Ix),uint8(Iy)),axis ij;
title('Quiver after Spatial Derivatives');
figure(2);
imshow(SI2);
quiver(fx,fy),axis ij;
title('Quiver normal flow');
figure(3);
imshow(mat2gray(Ix));
title('Spatial derivative w.r.t x');
figure(4);
imshow(mat2gray(Iy));
title('Spatial derivative w.r.t y');
figure(5);
imshow(mat2gray(t));
title('temporal gradient');
figure(6);
imshow(mat2gray(fy));
title('normal flow');
%{
for i=1:2
    for j=1:2
        A1(i,j) = A(i,j);
        b1(j)=b(j);
        v(i,j,:) = pinv(A1'*A1)*A1'*b1';
    end
end
quiver(v(1:1:2,1:1:2,1),v(1:1:2,1:1:2,2),4)
%}
kernel = ones(3);
v=zeros(266,534,2);
A1 = zeros(25,2);
for i = ceil(size(kernel,1)/2)+1 :1: size(I2,1)-size(kernel,1)+ceil(size(kernel,1)/2)-1
for j = ceil(size(kernel,2)/2)+1 :1: size(I2,2)-size(kernel,2)+ceil(size(kernel,2)/2)-1
ta=1;
for a=-ceil(size(kernel,1)/2):1:ceil(size(kernel,1)/2)
for b=-ceil(size(kernel,1)/2):1:ceil(size(kernel,1)/2)
A1(ta,1) = Ix(i+a,j+b);
A1(ta,2) = Iy(i+a,j+b);
b(ta) = -t(i+a,j+b);
ta=ta+1;
end
end
v(i,j,:) = pinv(A1'*A1)*A1'*b';
end
end
figure(7);quiver(v(1:1:1078,1:1:1918,1),v(1:1:1078,1:1:1918,2),4),axis ij;

%%%%%%%%%%%%% Bonus HomeWork %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% Horn and Schunk Algorithm %%%%%%%%%%%%%%%%%%%
kernel_1 = 0.25*[0 1 0;1 0 1;0 1 0];
u =zeros(size(I2,1),size(I2,2));
v=zeros(size(I2,1),size(I2,2));
alpha=2;
for i=1:25
mean_u=conv2(u,kernel_1,'same');
mean_v=conv2(v,kernel_1,'same');
u= mean_u - (Ix.*((Ix.*mean_u) + (Iy.*mean_v) + t))./(alpha^2 + Ix.^2 + Iy.^2);
v= mean_v - (Iy.*((Ix.*mean_u) + (Iy.*mean_v) + t))./(alpha^2 + Ix.^2 + Iy.^2);
end
figure(8);quiver(u(1:1:1080,1:1:1920),v(1:1:1080,1:1:1920),4),axis ij;
